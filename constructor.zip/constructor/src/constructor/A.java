// default constructor
package constructor;

public class A {
	int rollno;
public A() {
System.out.println("constructor called");
 rollno=49;
}
public static void main(String[] args) {
	A obj=new A();// constructor called
	System.out.println("number value is:"+obj.rollno);
}
}