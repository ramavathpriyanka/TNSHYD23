package multilevelinheritance;

public class Vehicle {
void start() {
	System.out.println("starting vehicle");
}
}

