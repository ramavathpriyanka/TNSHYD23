package multilevelinheritance;

public class Car extends Vehicle {
	void accelerate() {
		System.out.println("accelerating car");
	}
}
