package multilevelinheritance;

public class SportsCar extends Car {
	void turboBoot() {
		System.out.println("activating turboboost");
	}
}