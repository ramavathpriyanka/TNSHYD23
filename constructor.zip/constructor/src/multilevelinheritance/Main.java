package multilevelinheritance;

public class Main {
	public static void main(String[] args) {
		SportsCar a1=new SportsCar();
		a1.turboBoot();
		a1.accelerate();
		a1.start();
	}
}
