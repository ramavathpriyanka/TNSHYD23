package methodoverriding;

public class B {
	void show() {
		System.out.println("B show()");
	}
}