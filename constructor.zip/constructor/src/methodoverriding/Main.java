package methodoverriding;

public class Main {
public static void main(String[] args) {
	B obj1=new B();
	obj1.show();
	B obj2=new C();
	obj2.show();
	
}
}
