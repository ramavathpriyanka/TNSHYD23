package methodoverriding;

public class C extends B{
		void show() {
			System.out.println("c show()");
		}
	}
