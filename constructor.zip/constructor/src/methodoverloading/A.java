package methodoverloading;

public class A {
double sub(int x,double y)
{
	return(x-y);
}
double sub(double x, int y)
{
	return(x-y);}
	double sub (double x,int y,float z)
	{
		return(x-y-z);
	}
	public static void main(String[] args) {
		int a=5;
		double b=7.5;
		float c=4.5f;
		double result;
		A obj=new A();
		result=obj.sub(a,b);
		System.out.println("sub is:"+result);
		result=obj.sub(b, a);
		System.out.println("sub is:"+result);
		result=obj.sub(b, a,c);
		System.out.println("sub is:"+result);
	}
}