package hierarchial;

public class Shape {
	public void methodShape() {
		System.out.println("displaying shape");
	}
}
