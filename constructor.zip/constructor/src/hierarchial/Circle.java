package hierarchial;

public class Circle extends Shape {
public void methodCircle() {
	System.out.println("circle area");
}
}
