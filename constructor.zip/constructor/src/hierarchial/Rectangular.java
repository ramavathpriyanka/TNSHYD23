package hierarchial;

public class Rectangular extends Shape{
	public void methodRectangular() {
		System.out.println("rectangular parameter");
	}
public static void main(String[] args) {
	{
		Shape obj1=new Shape();
		Circle obj2=new Circle();
		Rectangular obj3=new Rectangular();
		obj1.methodShape();
		obj2.methodCircle();
		obj3.methodRectangular();
	}
}
}
