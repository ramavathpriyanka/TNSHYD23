package constructor1;

public class B { 
	int rollno;
	public B(int x) {
System.out.println(" parameterized constructor called");
rollno=x;
}
public static void main(String[] args) {
	B obj=new B(49);// parameterized constructor called
	System.out.println("rollno is:"+obj.rollno);
}
}