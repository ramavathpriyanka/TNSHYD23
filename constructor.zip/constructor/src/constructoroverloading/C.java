package constructoroverloading;

public class C {
int rollno1;
double rollno2;
//default constructor
public C()
{
	System.out.println("default constructor called");
	rollno1=47;
	rollno2=66;
}
// parameterized constructor1
 public C(int x) {
	System.out.println("parameterized constructor1 called");
rollno1=x;
}
 //parameterized constructor2
 public C(int x,double z) {
	 System.out.println("parameterized constructor2 called");
	 rollno1=x;
	 rollno2=z;
 }
 void displayData()
 {
	 System.out.println("rollno1:"+rollno1+"\nrollno2:"+rollno2);
 }
 public static void main(String[] args) {
	C obj1=new C();// default constructor called
	obj1.displayData();
	C obj2=new C(48);//parameterized constructor called
    obj2.displayData();
	C obj3=new C(47,88);//parameterized constructor2 called
	obj3.displayData();
}
}
