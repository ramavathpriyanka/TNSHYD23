package singleinheritance;

public class E extends D {
	public void methodE() {
		System.out.println("child class method");
	}
public static void main(String args[]) {
	E e1=new E();
	e1.methodD();//calling superclass method
	e1.methodE();//calling local method
}	
}
