package singleinheritance;

public class D
{
public void methodD() {
	System.out.println("parent class method");
}
}

