package student;

public class Main3 {
	public static void main(String[] args) {
		Student3 s3=new Student3();
		s3.setAge(20);
		s3.setName("priya");
		s3.setGrade("A+");
		System.out.println(s3.details());
	}

}
