package student;

public class Main2 {
public static void main(String[] args) {
	Student2 s2= new Student2();
	s2.setAge(20);
	System.out.println(s2.getAge());
	s2.setName("vinay");
	System.out.println(s2.getName());
}
}
