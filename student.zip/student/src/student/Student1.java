package student;

public class Student1 {
	private String name;
	private String grade;
	public int age;
}
