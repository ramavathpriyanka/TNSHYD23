package student;

public class Student3 {
	 private String name;
	 private String grade;
	 private int age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	 public String details() {
		 if(name.equals("John") && grade.equals("A") && age >18  ) {
			 return "true";
		 }
		 else {
			 return "no true";
		 }
	 }
	}

