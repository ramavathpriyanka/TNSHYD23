package employee;

public class Employee3 {
private String name;
private String designation;
private int age;
 public String getName() {
	 return name;
 }
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public void setName(String name) {
	this.name = name;
}
public String details() {
	if(name.equals("priya")&& designation.equals("government employee")&&  age>35) {
		return "yes";
	}else {
		return "no, She is not a government employee";
	}
}
}