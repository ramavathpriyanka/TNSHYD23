package employee;

public class Employee2 {
	private String name;
	private String designation;
	private int age;
	public int getAge() {
	return age;
}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public void setAge(int age) {
		this.age = age;
	}
}