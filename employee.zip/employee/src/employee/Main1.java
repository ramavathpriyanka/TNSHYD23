package employee;

public class Main1 {
	public static void main(String[] args) {
		Employee1 e1=new Employee1();
		e1.age=40;
		System.out.println("e1.age");
	}

}
