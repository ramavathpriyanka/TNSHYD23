package employee;

public class Employee1 {
	private String name;
	private String designation;
	public int age;

}
