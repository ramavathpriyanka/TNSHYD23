package employee;

public class Main3 {
public static void main(String[] args) {
	Employee3 e3=new Employee3();
	e3.setAge(45);
	e3.setName("shankar");
	e3.setDesignation("software employee");
	System.out.println(e3.details());
}
}
