package employee;

public class Main2 {
	public static void main(String[] args) {
		Employee2 e2= new Employee2();
		e2.setAge(40);
		System.out.println(e2.getAge());
		e2.setName("vinay");
		System.out.println(e2.getName());
	}

}
