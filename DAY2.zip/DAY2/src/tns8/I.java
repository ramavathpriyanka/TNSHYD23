package tns8;  //public

public class I {
public void display() {
	System.out.println("tns");
}
}
