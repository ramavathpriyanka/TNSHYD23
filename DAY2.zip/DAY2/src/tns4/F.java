package tns4;
import E.*;
class F {
public static void main(String[] args) {
	E e1=new E();
	e1.display();
}
}
