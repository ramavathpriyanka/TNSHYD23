package tns7;
import tns6.*;
public class H extends G {
	public static void main(String[] args) {
		H h1=new H();
		h1.display();
	}

}
