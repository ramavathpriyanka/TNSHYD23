package tns12;

public class M {
	public void msg() {
		System.out.println("hello madam");
	}
}
