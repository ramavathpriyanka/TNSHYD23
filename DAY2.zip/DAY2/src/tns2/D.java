package tns2;

public class D {

}
