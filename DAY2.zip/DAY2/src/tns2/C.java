package tns2;

public class C {
	private static void main(String[] args) {
		MyClass obj=new MyClass();
		obj.display();
	}

}
