package tns1;

public class A {
public static void main(String[] args) {
	B b1=new B();
	System.out.println(b1.b);
	b1.display();
	System.out.println(B.c);
}
}
