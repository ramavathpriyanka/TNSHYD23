package tns13;
import tns10.*;
import tns11.*;
import tns12.*;
public class N {
public static void main(String[] args) {
	K k1=new K();
	L l1=new L();
	M m1=new M();
	k1.msg();
	l1.msg();
	m1.msg();
}
}
