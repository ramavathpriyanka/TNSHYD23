//default access modifier
package accessmodifier1;

public class A {
void display() {
	System.out.println("TNS session");
}
}
// output :compile time error