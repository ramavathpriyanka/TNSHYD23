package approach2;

public class B {
	public static void main(String[] args) {
		A a1=new A();
		System.out.println(a1.emp1);
		a1.display();
		System.out.println(A.emp2);
		A.display1();
		}
}
