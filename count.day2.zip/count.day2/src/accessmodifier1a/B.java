package accessmodifier1a;
import accessmodifier1.*;
public class B {
	public static void main(String[] args) {
		A obj=new A();
		obj.display();
	}
}
// output error:
// compile time errror