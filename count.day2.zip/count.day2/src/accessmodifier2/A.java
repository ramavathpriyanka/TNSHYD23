// protected access modifier
package accessmodifier2;

public class A {
	protected void display() {
		System.out.println("TNS session");
	}
}
