package user1;

public class M {
	public void msg() {
		System.out.println("gd evng");
	}
}