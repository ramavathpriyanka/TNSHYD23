package user1;

public class K {
	public void msg() {
		System.out.println("hello");
	}
}
