package user1;

public class L {
	public void msg() {
		System.out.println("hello sir");
	}
}
