// private accessmodifier2
package accessmodifier;
class B{
	private void diplay() {
		System.out.println("TNS session");
	}
}