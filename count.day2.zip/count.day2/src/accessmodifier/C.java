package accessmodifier;

public class C {
public static void main(String[] args) {
	A obj =new obj A();
	obj.display();
}
}
// error :display() has private access modifier in A
