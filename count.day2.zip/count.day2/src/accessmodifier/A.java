// private access modifier1
package accessmodifier;

public class A {
	private void display() {
		System.out.println(" TNS session");
	}
	public static void main(String[] args) {
		A obj=new A();
		obj.display();
	}}