// public access modifier
package accessmodifier3;
public class A {
public void display() {
	System.out.println("TNS session");
}
}