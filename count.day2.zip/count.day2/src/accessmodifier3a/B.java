package accessmodifier3a;
import accessmodifier3.*;
public class B {
public static void main(String[] args) {
	A obj = new A();
	obj.display();
}
}
