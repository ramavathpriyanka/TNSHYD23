package accessmodifier2a;
import accessmodifier2.*;
public class B extends A {
	public static void main(String[] args) {
		B obj= new B();
		obj.display();
	}
}
